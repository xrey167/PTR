# Typed Agent Behavior v0.2

A starter post-training dataset for Rust-like behavioral discipline:
ownership, borrowing, typestate, Option/Result, schema validation, capabilities,
generation validity, effects, typed tool dispatch, and cross-feature composition.

The targets contain observable decisions and typed state transitions, not hidden
chain-of-thought.

Held-out splits deliberately use unseen nominal types and longer action chains.
Strong train accuracy alone does not establish an internal type system; the OOD
and compositional tests are the important part.
