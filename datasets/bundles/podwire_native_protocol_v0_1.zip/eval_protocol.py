#!/usr/bin/env python3
import json,re,sys
CALL=re.compile(r'^PW1 CALL sid=([A-Za-z0-9_.-]+) id=([A-Za-z0-9_.-]+) fn=([A-Za-z0-9_.-]+) gen=([0-9]+|-) args=(.+)$')
PATS={
"HELLO":re.compile(r'^PW1 HELLO sid=\S+ agent=\S+ ver=1$'),
"DECL":re.compile(r'^PW1 DECL sid=\S+ cap=\S+$'),
"RET":re.compile(r'^PW1 RET sid=\S+ id=\S+ type=\S+ val=(.+)$'),
"ERR":re.compile(r'^PW1 ERR sid=\S+ id=\S+ code=\S+ detail=(.+)$'),
"EVT":re.compile(r'^PW1 EVT sid=\S+ topic=\S+ gen=([0-9]+|-) val=(.+)$'),
"ACK":re.compile(r'^PW1 ACK sid=\S+ id=\S+$'),
"CANCEL":re.compile(r'^PW1 CANCEL sid=\S+ id=\S+$'),
"REVOKE":re.compile(r'^PW1 REVOKE sid=\S+ target=\S+ gen=[0-9]+$'),
"BYE":re.compile(r'^PW1 BYE sid=\S+ reason=\S+$')
}
def canonical_json(s):
    try: obj=json.loads(s)
    except Exception: return False
    return json.dumps(obj,separators=(",",":"),sort_keys=True,ensure_ascii=False)==s
def validate(frame):
    if "\n" in frame or not frame.startswith("PW1 "): return False
    parts=frame.split(" ",2)
    if len(parts)<3: return False
    kind=parts[1]
    if kind=="CALL":
        m=CALL.match(frame)
        return bool(m and canonical_json(m.group(5)))
    p=PATS.get(kind)
    if not p: return False
    m=p.match(frame)
    if not m: return False
    if kind in ("RET","ERR"): return canonical_json(m.group(1))
    if kind=="EVT": return canonical_json(m.group(2))
    return True
if __name__=="__main__":
    for line in sys.stdin:
        s=line.rstrip("\n")
        print(json.dumps({"valid":validate(s),"frame":s},ensure_ascii=False))
