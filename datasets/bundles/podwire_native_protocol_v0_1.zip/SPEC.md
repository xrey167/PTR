# PodWire/1

A compact typed model↔runtime protocol intended for learned, canonical emission.

## Canonical frames

PW1 HELLO sid=<id> agent=<atom> ver=1
PW1 DECL sid=<id> cap=<capability>
PW1 CALL sid=<id> id=<call_id> fn=<function> gen=<uint64|-> args=<json>
PW1 RET sid=<id> id=<call_id> type=<type> val=<json>
PW1 ERR sid=<id> id=<call_id|-> code=<ERROR_CODE> detail=<json>
PW1 EVT sid=<id> topic=<atom> gen=<uint64|-> val=<json>
PW1 ACK sid=<id> id=<call_id|event_id>
PW1 CANCEL sid=<id> id=<call_id>
PW1 REVOKE sid=<id> target=<atom> gen=<uint64>
PW1 BYE sid=<id> reason=<atom>

Rules:
1. One frame per line.
2. `PW1` and frame kind are uppercase.
3. Fields use canonical order.
4. JSON is compact with lexicographically sorted object keys.
5. CALL requires the function's capability.
6. Generation-bound resources must use the live generation.
7. RET/ERR ids correspond to outstanding calls.
8. Older revoked generations are invalid.
9. Invalid requests yield ERR, never silent coercion.
10. Protocol mode contains no prose.
