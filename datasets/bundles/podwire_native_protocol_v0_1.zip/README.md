# PodWire Native Protocol v0.1

This is a starter dataset for making a model *speak and obey* a compact protocol
without re-reading a long tool schema on every turn.

It deliberately separates four things:

1. **Continued pretraining corpus** — exposure to protocol syntax and recurrent semantics.
2. **SFT** — maps intent/state to exact canonical frames and decodes frames back to typed semantics.
3. **Preference pairs** — canonical frame preferred over malformed/non-canonical alternatives.
4. **Held-out evaluation** — harder composition and session continuation.

A learned protocol can become a default behavioral language in the weights. That
is stronger than prompt-only tool use, but it still does not prove the transformer
has a hard internal parser or type checker. For production, combine the learned
behavior with grammar-constrained decoding/runtime validation.

The registry is only a starter. Replace or extend it with your actual Pod,
linter/formatter, memory, network, compiler, or agent operations.
